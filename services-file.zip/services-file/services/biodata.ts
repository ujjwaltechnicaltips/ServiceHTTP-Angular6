export interface IBiodates
{
userId:number,
id:number,
title:string,
body:string

}